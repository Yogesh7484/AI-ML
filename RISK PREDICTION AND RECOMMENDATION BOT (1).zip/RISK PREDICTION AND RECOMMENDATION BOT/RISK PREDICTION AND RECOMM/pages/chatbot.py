
# chatbot.py   manappuram
import streamlit as st
import pandas as pd
import google.generativeai as genai
from textblob import TextBlob
import os

# Configure Gemini API
genai.configure(api_key="*")  # Replace with your actual 
model = genai.GenerativeModel("gemini-1.5-flash")

st.set_page_config(page_title="🤖 Risk Chatbot", layout="centered")
st.title("💬 NBFC Risk Assistant")
st.caption("Ask anything related to the predicted customer risk results.")

# Ensure dataset is available
if "predicted_data" not in st.session_state:
    st.warning("⚠️ Please upload a dataset from the Home page first.")
    st.stop()

df = st.session_state.predicted_data

# Initialize chat history
if "chat_history" not in st.session_state:
    st.session_state.chat_history = []

# Display chat history in WhatsApp style
for msg in st.session_state.chat_history:
    with st.chat_message(msg["role"]):
        st.markdown(msg["content"])

# Input box for new message
user_input = st.chat_input("Type your question here...")

if user_input:
    # Show user's message
    st.chat_message("user").markdown(user_input)
    st.session_state.chat_history.append({"role": "user", "content": user_input})

    # Spelling correction
    corrected_input = str(TextBlob(user_input).correct())

    # Thinking placeholder
    with st.chat_message("assistant"):
        response_placeholder = st.empty()
        response_placeholder.markdown("🤔 Thinking...")

        # Prompt with data context
        try:
            full_prompt = f"""
You are a smart NBFC Risk Assistant. Use the following predicted customer data to answer questions:
{df.to_csv(index=False)}

Question: {corrected_input}
"""
            response = model.generate_content(full_prompt)
            reply = response.text.strip()
        except Exception as e:
            reply = f"❌ Sorry, something went wrong: {e}"

        response_placeholder.markdown(reply)
        st.session_state.chat_history.append({"role": "assistant", "content": reply})
